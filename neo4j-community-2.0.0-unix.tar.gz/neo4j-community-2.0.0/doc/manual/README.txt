Neo4j Manual
============

For convenience, the Neo4j Reference Manual is included in html and text form. 
For a PDF version of the Neo4j Manual, see http://docs.neo4j.org/

